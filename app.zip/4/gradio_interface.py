# gradio_interface.py
import gradio as gr
from backend.gemini_client import GeminiClient
from backend.prompt_templates import disease_diagnosis_prompt

g = GeminiClient()

def diagnose_image(image, crop_name="Wheat"):
    img_bytes = image.read()
    prompt = disease_diagnosis_prompt(crop=crop_name, image_notes="Uploaded via Gradio quick-check")
    res = g.analyze_image(img_bytes, prompt)
    return res

iface = gr.Interface(fn=diagnose_image,
                     inputs=[gr.Image(type="file"), gr.Textbox(label="Crop name")],
                     outputs="text",
                     title="Crop Quick Diagnostic (Gemini)")
if __name__ == "__main__":
    iface.launch(server_name="0.0.0.0", server_port=7860, share=False)
