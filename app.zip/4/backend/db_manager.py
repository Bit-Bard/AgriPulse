import mysql.connector
import os
from dotenv import load_dotenv

load_dotenv()

# Get DB Connection
def get_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASS", ""),
        database=os.getenv("DB_NAME", "krishi_ai")
    )

# ------------------------
# Farmers Onboarding
# ------------------------
def insert_farmer(name, phone, crop_choice, season, location, language_pref="en"):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO farmers (name, phone, crop_choice, season, location, language_pref)
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (name, phone, crop_choice, season, location, language_pref))
    conn.commit()
    farmer_id = cursor.lastrowid
    conn.close()
    return farmer_id

def get_farmer(farmer_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM farmers WHERE id = %s", (farmer_id,))
    result = cursor.fetchone()
    conn.close()
    return result

# ------------------------
# Crop Monitoring
# ------------------------
def insert_crop_monitoring(farmer_id, photo_path, analysis_report, report_date):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO crop_monitoring (farmer_id, photo_path, analysis_report, report_date)
        VALUES (%s, %s, %s, %s)
    """
    cursor.execute(query, (farmer_id, photo_path, analysis_report, report_date))
    conn.commit()
    conn.close()

def get_crop_reports(farmer_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM crop_monitoring WHERE farmer_id = %s", (farmer_id,))
    results = cursor.fetchall()
    conn.close()
    return results

# ------------------------
# Crop Health
# ------------------------
def insert_crop_health(farmer_id, issue_detected, treatment_suggestion, uploaded_photo):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO crop_health (farmer_id, issue_detected, treatment_suggestion, uploaded_photo)
        VALUES (%s, %s, %s, %s)
    """
    cursor.execute(query, (farmer_id, issue_detected, treatment_suggestion, uploaded_photo))
    conn.commit()
    conn.close()

def get_crop_health(farmer_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM crop_health WHERE farmer_id = %s", (farmer_id,))
    results = cursor.fetchall()
    conn.close()
    return results

# ------------------------
# Market Links
# ------------------------
def insert_market_link(farmer_id, buyer_name, offered_price, best_time_to_sell):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO market_links (farmer_id, buyer_name, offered_price, best_time_to_sell)
        VALUES (%s, %s, %s, %s)
    """
    cursor.execute(query, (farmer_id, buyer_name, offered_price, best_time_to_sell))
    conn.commit()
    conn.close()

def get_market_links(farmer_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM market_links WHERE farmer_id = %s", (farmer_id,))
    results = cursor.fetchall()
    conn.close()
    return results

# ------------------------
# Govt Schemes
# ------------------------
def insert_govt_scheme(farmer_id, scheme_name, description, eligibility, benefit):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO govt_schemes (farmer_id, scheme_name, description, eligibility, benefit)
        VALUES (%s, %s, %s, %s, %s)
    """
    cursor.execute(query, (farmer_id, scheme_name, description, eligibility, benefit))
    conn.commit()
    conn.close()

def get_govt_schemes(farmer_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM govt_schemes WHERE farmer_id = %s", (farmer_id,))
    results = cursor.fetchall()
    conn.close()
    return results

# ------------------------
# Weather Alerts
# ------------------------
def insert_weather_alert(farmer_id, alert_type, alert_message, alert_date, severity):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO weather_alerts (farmer_id, alert_type, alert_message, alert_date, severity)
        VALUES (%s, %s, %s, %s, %s)
    """
    cursor.execute(query, (farmer_id, alert_type, alert_message, alert_date, severity))
    conn.commit()
    conn.close()

def get_weather_alerts(farmer_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM weather_alerts WHERE farmer_id = %s", (farmer_id,))
    results = cursor.fetchall()
    conn.close()
    return results
