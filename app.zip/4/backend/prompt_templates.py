# backend/prompt_templates.py
from typing import List

# Farmer-friendly language note included in each prompt.
FARMER_FRIENDLY = "Keep answers short, actionable and farmer-friendly. Use simple words, avoid technical jargon. Prefer bullet points for actions."

def crop_suggestion_prompt(state: str, district: str, season: str, soil_ph: float = None, soil_photo_hint: str = None, crop_history: List[str] = None):
    crop_history = ", ".join(crop_history) if crop_history else "no history provided"
    p = f"""
You are an agronomist assistant for small farmers in India.
Context:
- State: {state}
- District: {district}
- Season: {season}
- Soil pH (if provided): {soil_ph}
- Farmer crop history: {crop_history}
Task:
1) Suggest top 3 crops best suited (ranked) with brief reasons (1-2 lines each).
2) For each suggested crop give: expected growing period (weeks), water need (low/medium/high), seed rate (kg/acre), sowing window (dates), and quick farming tips (3 bullets).
3) If {soil_ph} is missing but you have soil_photo_hint, analyze from photo hint and estimate soil pH range and whether to add lime/acidifier.
{FARMER_FRIENDLY}
Provide output as JSON with fields: recommendations (array of objects).
"""
    return p

def disease_diagnosis_prompt(crop: str, image_notes: str = ""):
    return f"""
You are an experienced plant pathologist. The farmer uploaded a photo for crop: {crop}.
Image notes: {image_notes}
Task:
- Identify likely disease(s), pests, or nutrient deficiency with confidence levels.
- Provide 3 immediate actions the farmer can take (safe, low-cost, and locally-available options).
- Give simple remedial steps and one preventive tip.
{FARMER_FRIENDLY}
Give the result in JSON with fields: diagnoses (list), actions (list), prevention (string).
"""

def supplier_comparison_prompt(crop: str, product_type: str, quantity_kg: int, location: str):
    return f"""
Simulate 5 realistic suppliers for {product_type} (seed/fertilizer/pesticide) for {crop} near {location}.
Return a JSON array of 5 suppliers each with:
- name, price_per_kg (INR), min_order_kg, delivery_days, product_grade, likely_safety_notes, trust_score (1-5).
Highlight which is 'best_value' (cheap + good grade) and which is 'cheapest'.
{FARMER_FRIENDLY}
"""

def weather_alert_prompt(state: str, district: str, season: str):
    return f"""
You are an agricultural weather forecaster. For {district}, {state} during {season}, provide:
- Short-term (next 7 days) risk alerts (storms/heavy rainfall/heatwaves) with confidence 0-100.
- Practical farmer actions if each risk occurs (do X within Y hours).
- If no live MET data available, use historical patterns and conservative risk estimates.
{FARMER_FRIENDLY}
Output JSON with alerts array.
"""

def market_linkage_prompt(crop: str, state: str, harvest_month: str):
    return f"""
You are a market analyst for agriculture in India.
Given crop: {crop}, state: {state}, harvest_month: {harvest_month}:
- Simulate 4 buyer types (local mandi, aggregator, processor, exporter) with typical offered_price_range(INR/kg), commission/fees(%), pickup_time, and payment_terms.
- For each buyer recommend best selling time (month/week) and estimated gross price.
Return JSON.
{FARMER_FRIENDLY}
"""
