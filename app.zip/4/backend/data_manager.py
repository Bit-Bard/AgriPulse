import os
import mysql.connector
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

DB_HOST = os.getenv("DB_HOST", "localhost")
DB_USER = os.getenv("DB_USER", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_NAME = os.getenv("DB_NAME", "krishi_ai")

def get_connection():
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )

# ------------------------------
# Farmers
# ------------------------------
def insert_farmer(name, phone, crop_choice, season, location):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO farmers (name, phone, crop_choice, season, location) VALUES (%s, %s, %s, %s, %s)",
        (name, phone, crop_choice, season, location)
    )
    conn.commit()
    cur.close()
    conn.close()

def get_farmer(phone):
    conn = get_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM farmers WHERE phone = %s", (phone,))
    row = cur.fetchone()
    cur.close()
    conn.close()
    return row

# ------------------------------
# Reports
# ------------------------------
def insert_report(farmer_id, report_type, content):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO reports (farmer_id, report_type, content, generated_at) VALUES (%s, %s, %s, %s)",
        (farmer_id, report_type, content, datetime.now())
    )
    conn.commit()
    cur.close()
    conn.close()

def get_reports(farmer_id):
    conn = get_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM reports WHERE farmer_id = %s ORDER BY generated_at DESC", (farmer_id,))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows

# ------------------------------
# Crop Monitoring
# ------------------------------
def insert_crop_report(farmer_id, report_date, analysis_report):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO crop_reports (farmer_id, report_date, analysis_report) VALUES (%s, %s, %s)",
        (farmer_id, report_date, analysis_report)
    )
    conn.commit()
    cur.close()
    conn.close()

def get_crop_reports(farmer_id):
    conn = get_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM crop_reports WHERE farmer_id = %s ORDER BY report_date DESC", (farmer_id,))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows

# ------------------------------
# Crop Health
# ------------------------------
def insert_health_report(farmer_id, checked_at, issue_detected, treatment_suggestion):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO health_reports (farmer_id, checked_at, issue_detected, treatment_suggestion) VALUES (%s, %s, %s, %s)",
        (farmer_id, checked_at, issue_detected, treatment_suggestion)
    )
    conn.commit()
    cur.close()
    conn.close()

def get_health_reports(farmer_id):
    conn = get_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM health_reports WHERE farmer_id = %s ORDER BY checked_at DESC", (farmer_id,))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows
