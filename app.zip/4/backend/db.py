# backend/db.py
import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "agri_app.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS farmers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        phone TEXT,
        crop_choice TEXT,
        season TEXT,
        state TEXT,
        district TEXT,
        locality TEXT,
        language TEXT,
        lat REAL,
        lon REAL,
        created_at TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        farmer_id INTEGER,
        path TEXT,
        uploaded_at TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        farmer_id INTEGER,
        path TEXT,
        generated_at TEXT
    )
    """)
    conn.commit()
    conn.close()

def add_farmer(data: dict):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO farmers (name, phone, crop_choice, season, state, district, locality, language, lat, lon, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (data.get("name"), data.get("phone"), data.get("crop_choice"), data.get("season"),
          data.get("state"), data.get("district"), data.get("locality"), data.get("language"),
          data.get("lat"), data.get("lon"), datetime.utcnow().isoformat()))
    conn.commit()
    fid = cur.lastrowid
    conn.close()
    return fid

def list_farmers():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM farmers ORDER BY created_at DESC")
    rows = cur.fetchall()
    conn.close()
    return rows

def add_image(farmer_id: int, path: str):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO images (farmer_id, path, uploaded_at) VALUES (?, ?, ?)",
                (farmer_id, path, datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()

def add_report(farmer_id: int, path: str):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO reports (farmer_id, path, generated_at) VALUES (?, ?, ?)",
                (farmer_id, path, datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()
