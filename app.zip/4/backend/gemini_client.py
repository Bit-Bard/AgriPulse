# backend/gemini_client.py
import os
from dotenv import load_dotenv

# Install: pip install google-genai
from google import genai

load_dotenv()

DEFAULT_MODEL = "gemini-2.5-flash"

class GeminiClient:
    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not set in environment (.env).")
        # initialize client
        self.client = genai.Client(api_key=api_key)
        self.model = DEFAULT_MODEL

    # Primary text call
    def ask_text(self, prompt: str, model: str = None) -> str:
        model = model or self.model
        resp = self.client.models.generate_content(
            model=model,
            contents=prompt
        )
        return getattr(resp, "text", str(resp))

    # Alias for backward compatibility
    def generate_text(self, prompt: str, model: str = None) -> str:
        return self.ask_text(prompt, model)

    # Analyze image bytes. Accepts bytes and optional mime_type (jpg/png)
    def analyze_image(self, image_bytes: bytes, instruction: str = "Analyze the image", mime_type: str = "image/jpeg", model: str = None) -> str:
        model = model or self.model
        # SDK allows passing dict with mime_type & data
        part = {"mime_type": mime_type, "data": image_bytes}
        resp = self.client.models.generate_content(
            model=model,
            contents=[part, instruction]
        )
        return getattr(resp, "text", str(resp))

    # Transcribe / analyze audio bytes
    def transcribe_audio(self, audio_bytes: bytes, instruction: str = "Transcribe the audio", mime_type: str = "audio/wav", model: str = None) -> str:
        model = model or self.model
        part = {"mime_type": mime_type, "data": audio_bytes}
        resp = self.client.models.generate_content(
            model=model,
            contents=[part, instruction]
        )
        return getattr(resp, "text", str(resp))

    # Simple translate wrapper (farmer-friendly)
    def translate(self, text: str, target_lang: str = "hi") -> str:
        prompt = f"Translate to {target_lang}. Keep it short, clear and farmer-friendly:\n\n{text}"
        return self.ask_text(prompt)
