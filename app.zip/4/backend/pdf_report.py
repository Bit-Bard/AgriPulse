# backend/pdf_report.py
import os
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from datetime import datetime
from reportlab.lib.utils import ImageReader

def generate_farmer_report_pdf(farmer_data: dict, analysis_text: str, image_paths: list, out_path: str):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    c = canvas.Canvas(out_path, pagesize=A4)
    width, height = A4

    c.setFont("Helvetica-Bold", 16)
    c.drawString(40, height - 50, f"Farm Report - {farmer_data.get('name','N/A')}")
    c.setFont("Helvetica", 10)
    c.drawString(40, height - 70, f"Phone: {farmer_data.get('phone','N/A')}  |  Crop: {farmer_data.get('crop_choice','N/A')}")
    c.drawString(40, height - 85, f"Location: {farmer_data.get('location','N/A')}")
    c.drawString(40, height - 100, f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")

    y = height - 130
    c.setFont("Helvetica", 11)
    for line in analysis_text.splitlines():
        c.drawString(40, y, line[:110])
        y -= 14
        if y < 120:
            c.showPage()
            y = height - 80
            c.setFont("Helvetica", 11)

    # add thumbnails
    for p in image_paths:
        try:
            if y < 180:
                c.showPage()
                y = height - 80
            img = ImageReader(p)
            iw, ih = img.getSize()
            max_w = 220
            scale = min(max_w / iw, 120 / ih, 1)
            w2, h2 = iw * scale, ih * scale
            c.drawImage(img, 40, y - h2, width=w2, height=h2)
            y -= h2 + 12
        except Exception:
            continue

    c.save()
    return out_path
