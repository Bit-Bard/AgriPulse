import os

# Define directory structure
dirs = [
    "backend"
]

files = [
    "requirements.txt",
    ".env.example",
    "backend/gemini_client.py",
    "backend/prompt_templates.py",
    "backend/db.py",
    "backend/pdf_report.py",
    "utils.py",
    "app_streamlit.py",
    "gradio_interface.py",
    "README_DEPLOY.md"
]

def create_structure():
    # Create directories
    for d in dirs:
        os.makedirs(d, exist_ok=True)

    # Create files
    for f in files:
        if not os.path.exists(f):
            with open(f, "w", encoding="utf-8") as fp:
                fp.write("")  # empty file
            print(f"Created: {f}")
        else:
            print(f"Already exists: {f}")

if __name__ == "__main__":
    create_structure()
    print("\n Project structure created successfully!")
