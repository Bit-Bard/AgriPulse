import os
import streamlit as st
from datetime import datetime
from streamlit_webrtc import webrtc_streamer

from backend.gemini_client import GeminiClient
from backend.pdf_report import generate_farmer_report_pdf
from utils import save_uploaded_file, DATA_DIR
from backend import data_manager

# Init Gemini client
g = GeminiClient()

st.set_page_config(page_title="Krishi AI", layout="wide")
st.title("🌱 Krishi AI - Smart Agriculture Assistant")

menu = [
    "Farmer Onboarding",
    "Crop Suggestion",
    "Seed/Fertilizer/Pesticide Comparison",
    "Crop Monitoring",
    "Crop Health Checkup",
    "Weather Alerts",
    "Government Schemes",
    "Market Linkage",
    "Reports",
    "Voice Input"
]
choice = st.sidebar.radio("📌 Select Feature", menu)

# ----------------------------
# Farmer Onboarding
# ----------------------------
if choice == "Farmer Onboarding":
    st.subheader("👨‍🌾 Farmer Onboarding")

    with st.form("onboard_form"):
        name = st.text_input("Farmer Name")
        phone = st.text_input("Phone Number")
        crop_choice = st.text_input("Preferred Crop (if any)")
        season = st.selectbox("Season", ["Summer", "Winter", "Monsoon"])
        location = st.text_input("Location (State/District/Locality)")
        submitted = st.form_submit_button("Save Farmer")

    if submitted:
        data_manager.insert_farmer(name, phone, crop_choice, season, location)
        st.success(f"Farmer {name} registered successfully ✅")

# ----------------------------
# Crop Suggestion
# ----------------------------
elif choice == "Crop Suggestion":
    st.subheader("🌾 Crop Suggestion")
    phone = st.text_input("Enter your registered phone number")

    if st.button("Get Suggestion"):
        farmer = data_manager.get_farmer(phone)
        if farmer:
            prompt = f"Suggest best crops for {farmer['location']} during {farmer['season']} season. Farmer prefers {farmer['crop_choice']}."
            suggestion = g.ask_text(prompt)
            st.info(suggestion)
            data_manager.insert_report(farmer["id"], "crop_suggestion", suggestion)
        else:
            st.error("Farmer not found!")

# ----------------------------
# Seed/Fertilizer/Pesticide Comparison
# ----------------------------
elif choice == "Seed/Fertilizer/Pesticide Comparison":
    st.subheader("🌱 Input Comparison")
    phone = st.text_input("Farmer Phone Number")

    if st.button("Compare Inputs"):
        farmer = data_manager.get_farmer(phone)
        if farmer:
            prompt = f"Simulate data from 5 suppliers for seeds, fertilizers and pesticides in {farmer['location']}. Compare price and quality. Highlight cheapest and best."
            comparison = g.ask_text(prompt)
            st.write(comparison)
            data_manager.insert_report(farmer["id"], "input_comparison", comparison)
        else:
            st.error("Farmer not found!")

# ----------------------------
# Crop Monitoring
# ----------------------------
elif choice == "Crop Monitoring":
    st.subheader("📸 Crop Monitoring")
    phone = st.text_input("Farmer Phone Number")
    img = st.file_uploader("Upload daily crop photo", type=["jpg", "jpeg", "png"])

    if st.button("Analyze Growth") and img:
        farmer = data_manager.get_farmer(phone)
        if farmer:
            img_path = save_uploaded_file(img, "monitoring")
            report = g.analyze_image(img_path, "Analyze crop growth and health, give a farmer-friendly daily report.")
            st.info(report)
            data_manager.insert_crop_report(farmer["id"], datetime.today().date(), report)
        else:
            st.error("Farmer not found!")

# ----------------------------
# Crop Health Checkup
# ----------------------------
elif choice == "Crop Health Checkup":
    st.subheader("🩺 Crop Health Checkup")
    phone = st.text_input("Farmer Phone Number")
    img = st.file_uploader("Upload crop image for disease diagnosis", type=["jpg", "jpeg", "png"])

    if st.button("Diagnose Health") and img:
        farmer = data_manager.get_farmer(phone)
        if farmer:
            img_path = save_uploaded_file(img, "health")
            diagnosis = g.analyze_image(img_path, "Identify diseases, pests, or nutrient issues. Suggest treatments.")
            st.info(diagnosis)
            data_manager.insert_health_report(farmer["id"], datetime.now(), "Detected issue", diagnosis)
        else:
            st.error("Farmer not found!")

# ----------------------------
# Weather Alerts
# ----------------------------
elif choice == "Weather Alerts":
    st.subheader("🌦 Weather Alerts")
    phone = st.text_input("Farmer Phone Number")

    if st.button("Get Alerts"):
        farmer = data_manager.get_farmer(phone)
        if farmer:
            prompt = f"Provide upcoming weather alerts, storms, and rainfall predictions for {farmer['location']} in {farmer['season']}."
            alerts = g.ask_text(prompt)
            st.warning(alerts)
            data_manager.insert_report(farmer["id"], "weather_alerts", alerts)
        else:
            st.error("Farmer not found!")

# ----------------------------
# Government Schemes
# ----------------------------
elif choice == "Government Schemes":
    st.subheader("🏛 Government Schemes")
    phone = st.text_input("Farmer Phone Number")

    if st.button("Fetch Schemes"):
        farmer = data_manager.get_farmer(phone)
        if farmer:
            prompt = f"List top 5 government schemes and benefits for farmers in {farmer['location']} growing {farmer['crop_choice']}."
            schemes = g.ask_text(prompt)
            st.info(schemes)
            data_manager.insert_report(farmer["id"], "govt_schemes", schemes)
        else:
            st.error("Farmer not found!")

# ----------------------------
# Market Linkage
# ----------------------------
elif choice == "Market Linkage":
    st.subheader("💹 Market Linkage")
    phone = st.text_input("Farmer Phone Number")

    if st.button("Get Buyers"):
        farmer = data_manager.get_farmer(phone)
        if farmer:
            prompt = f"Compare 4-5 potential buyers for {farmer['crop_choice']} in {farmer['location']}. Suggest best selling time and price."
            market = g.ask_text(prompt)
            st.success(market)
            data_manager.insert_report(farmer["id"], "market_linkage", market)
        else:
            st.error("Farmer not found!")

# ----------------------------
# Reports
# ----------------------------
elif choice == "Reports":
    st.subheader("📑 Farmer Reports")
    phone = st.text_input("Farmer Phone Number")

    if st.button("Fetch Reports"):
        farmer = data_manager.get_farmer(phone)
        if farmer:
            reports = data_manager.get_reports(farmer["id"])
            if reports:
                for r in reports:
                    st.markdown(f"### 📝 {r['report_type']} - {r['generated_at']}")
                    st.write(r["content"])
                if st.button("Download Latest Report as PDF"):
                    pdf_path = generate_farmer_report_pdf(farmer, reports[0]["content"])
                    with open(pdf_path, "rb") as f:
                        st.download_button("Download PDF", f, file_name="farmer_report.pdf", mime="application/pdf")
            else:
                st.warning("No reports found.")
        else:
            st.error("Farmer not found!")

# ----------------------------
# Voice Input
# ----------------------------
elif choice == "Voice Input":
    st.subheader("🎙️ Voice to Text + Gemini")

    webrtc_ctx = webrtc_streamer(
        key="speech",
        mode="sendonly",
        audio_receiver_size=256,
        media_stream_constraints={"audio": True, "video": False}
    )

    audio_file_path = os.path.join(DATA_DIR, "voice_input.wav")

    if webrtc_ctx.audio_receiver:
        audio_frames = webrtc_ctx.audio_receiver.get_frames(timeout=1)
        if audio_frames:
            audio = audio_frames[0]
            with open(audio_file_path, "wb") as f:
                f.write(audio.to_ndarray().tobytes())

            st.success("🎧 Voice captured! Sending to Gemini...")
            transcript = g.transcribe_audio(audio_file_path)
            st.text_area("📝 Transcription:", transcript)

            if st.button("Ask Gemini"):
                answer = g.ask_text(transcript)
                st.info(answer)
