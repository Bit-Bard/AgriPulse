# utils.py
import os
import re
from datetime import datetime
DATA_DIR = "data"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
IMAGES_DIR = os.path.join(DATA_DIR, "images")
PDF_DIR = os.path.join(DATA_DIR, "pdfs")

for d in (DATA_DIR, IMAGES_DIR, PDF_DIR):
    os.makedirs(d, exist_ok=True)

def safe_filename(name: str) -> str:
    name = re.sub(r"[^A-Za-z0-9_.-]", "_", name)
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    return f"{ts}_{name}"

def save_uploaded_file_bytes(file_bytes: bytes, filename: str, subdir="images") -> str:
    d = IMAGES_DIR if subdir == "images" else os.path.join(DATA_DIR, subdir)
    os.makedirs(d, exist_ok=True)
    fname = safe_filename(filename)
    path = os.path.join(d, fname)
    with open(path, "wb") as fw:
        fw.write(file_bytes)
    return path

def save_uploaded_file(uploaded_file, subfolder=""):
    folder = os.path.join(DATA_DIR, subfolder)
    os.makedirs(folder, exist_ok=True)
    file_path = os.path.join(folder, uploaded_file.name)
    with open(file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return file_path