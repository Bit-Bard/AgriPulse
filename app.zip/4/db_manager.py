import mysql.connector
import os
from dotenv import load_dotenv

load_dotenv()

def get_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASS", ""),
        database=os.getenv("DB_NAME", "krishi_ai")
    )

def insert_farmer(name, phone, crop_choice, season, location, language_pref="en"):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO farmers (name, phone, crop_choice, season, location, language_pref)
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (name, phone, crop_choice, season, location, language_pref))
    conn.commit()
    farmer_id = cursor.lastrowid
    conn.close()
    return farmer_id
